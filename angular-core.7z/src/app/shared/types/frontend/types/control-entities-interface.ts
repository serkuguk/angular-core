import {ControlInterface} from '@app/shared/types/frontend/types/control-interface';

export interface ControlEntitiesInterface {
  [key: string]: ControlInterface
}
