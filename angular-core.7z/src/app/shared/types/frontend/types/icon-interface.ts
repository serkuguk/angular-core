export interface IconInterface {
  src: string
  cssClass: string
}
