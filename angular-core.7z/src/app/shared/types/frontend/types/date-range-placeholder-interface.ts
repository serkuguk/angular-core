export interface DateRangePlaceholderInterface{
  from: string
  to: string
}
