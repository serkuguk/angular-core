export interface DateRangeValueInterface {
  from: string
  to: string
}
