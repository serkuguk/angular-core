export interface Icon {
  src: string;
  cssClass: string;
}
