export interface Role {
  name: string;
}

export enum Roles {
  Admin = 'admin'
}