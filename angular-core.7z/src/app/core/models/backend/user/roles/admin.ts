export interface Admin {
  user: string;
  uid: number;
}