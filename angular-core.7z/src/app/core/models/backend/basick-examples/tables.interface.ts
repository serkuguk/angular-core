export interface BasicDataInterface {
  name: string | null;
  balance: string | null;
}
