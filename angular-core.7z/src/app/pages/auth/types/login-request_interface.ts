export interface LoginRequestInterface {
  username: string
  password: string
}
