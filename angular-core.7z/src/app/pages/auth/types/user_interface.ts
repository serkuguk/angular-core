export interface UserInterface {
  uid: number
  username: string
  firstname: string
  lastname: string
  bio: string
}
