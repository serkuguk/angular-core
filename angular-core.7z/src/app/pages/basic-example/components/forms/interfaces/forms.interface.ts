export interface Address {
  city?: string;
  street?: string;
  building?: number;
  apartment?: number;
}
