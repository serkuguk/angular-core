export const environment = {
  production: true,
  token_header_key: 'Authorization',
  server_url: 'http://localhost:8080/api'
};
