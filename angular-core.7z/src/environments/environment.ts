export const environment = {
  production: false,
  token_header_key: 'Authorization',
  server_url: 'http://localhost:3000/api'
};
