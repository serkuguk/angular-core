## 1.0.3 (WIP)
```
[develop] added nav bar left side
```

```
[develop] udate version of taigaui from 3.80.0 to 3.81.0
```

## 1.0.2 27/05/2024
```
[develop] upgrate version of angular core from 17.0.1 to 17.2.4
```

```
[develop] upgrate version of angular core from 17.2.4 to 18.0.0
```

```
[develop] upgrate taiga-ui version from 3.76.0 to 3.80.0
```